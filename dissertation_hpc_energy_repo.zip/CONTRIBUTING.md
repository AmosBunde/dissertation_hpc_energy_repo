
# Contributing
1. Fork and create a feature branch.
2. Add tests/notebooks where relevant.
3. Use clear commit messages and PR descriptions.
4. No sensitive data in PRs. Respect NDAs/DUAs.
