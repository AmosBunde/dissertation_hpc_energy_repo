
Store experiment configs/results here (avoid committing large raw data).
