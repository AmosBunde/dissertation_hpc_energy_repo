#!/usr/bin/env bash
set -euo pipefail
echo '[placeholder] Hook your batsim command here'
